const data = {
  "徑賽": {
    "100M": {
      "一年級男生組": [
        { name: "王小明", result: "12.35秒" },
        { name: "李大仁", result: "12.70秒" }
      ],
      "一年級女生組": [
        { name: "林美美", result: "13.80秒" }
      ]
    },
    "200M": {
      "一年級男生組": [
        { name: "陳彥廷", result: "25.40秒" }
      ]
    }
  },
  "田賽": {
    "跳遠": {
      "一年級男生組": [
        { name: "張偉", result: "4.85m" }
      ]
    }
  },
  "趣味競賽": {
    "一年級兩人三腳": {
      "一年級男生組": [
        { name: "阿東與阿志", result: "1分05秒" }
      ]
    }
  }
};

function updateMarquee() {
  const marquee = document.getElementById("marquee");
  const input = document.getElementById("marqueeInput").value;
  marquee.innerText = input || "歡迎查詢成績";
}

function populateEvents() {
  const category = document.getElementById("categorySelect").value;
  const eventSelect = document.getElementById("eventSelect");
  eventSelect.innerHTML = "";
  if (data[category]) {
    Object.keys(data[category]).forEach(event => {
      const option = document.createElement("option");
      option.value = event;
      option.innerText = event;
      eventSelect.appendChild(option);
    });
    showResults();
  }
}

function showResults() {
  const category = document.getElementById("categorySelect").value;
  const event = document.getElementById("eventSelect").value;
  const search = document.getElementById("searchInput").value;
  const table = document.getElementById("resultsTable");
  table.innerHTML = "<tr><th>組別</th><th>姓名</th><th>成績</th></tr>";

  if (data[category] && data[category][event]) {
    const groupData = data[category][event];
    Object.keys(groupData).forEach(group => {
      groupData[group].forEach(item => {
        if (!search || item.name.includes(search)) {
          const row = table.insertRow();
          row.insertCell(0).innerText = group;
          row.insertCell(1).innerText = item.name;
          row.insertCell(2).innerText = item.result;
        }
      });
    });
  }
}

window.onload = populateEvents;